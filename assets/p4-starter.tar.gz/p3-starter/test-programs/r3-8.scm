(program
  (let* ([a (make-vector 8)]
         [b (make-vector 8)]
         [c (make-vector 8)]
         ;; initialize a with reads
         [a0 (read)] [_ (vector-set! a 0 a0)]
         [a1 (read)] [_ (vector-set! a 1 a1)]
         [a2 (read)] [_ (vector-set! a 2 a2)]
         [a3 (read)] [_ (vector-set! a 3 a3)]
         [a4 (read)] [_ (vector-set! a 4 a4)]
         [a5 (read)] [_ (vector-set! a 5 a5)]
         [a6 (read)] [_ (vector-set! a 6 a6)]
         [a7 (read)] [_ (vector-set! a 7 a7)]
         ;; initialize b with transformed constants from a (constant indices)
         [_ (vector-set! b 0 (+ (vector-ref a 0) 1))]
         [_ (vector-set! b 1 (+ (vector-ref a 1) 2))]
         [_ (vector-set! b 2 (+ (vector-ref a 2) 3))]
         [_ (vector-set! b 3 (+ (vector-ref a 3) 4))]
         [_ (vector-set! b 4 (+ (vector-ref a 4) 5))]
         [_ (vector-set! b 5 (+ (vector-ref a 5) 6))]
         [_ (vector-set! b 6 (+ (vector-ref a 6) 7))]
         [_ (vector-set! b 7 (+ (vector-ref a 7) 8))]
         ;; compute c as a +/- b alternation
         [_ (vector-set! c 0 (+ (vector-ref a 0) (vector-ref b 0)))]
         [_ (vector-set! c 1 (- (vector-ref a 1) (vector-ref b 1)))]
         [_ (vector-set! c 2 (+ (vector-ref a 2) (vector-ref b 2)))]
         [_ (vector-set! c 3 (- (vector-ref a 3) (vector-ref b 3)))]
         [_ (vector-set! c 4 (+ (vector-ref a 4) (vector-ref b 4)))]
         [_ (vector-set! c 5 (- (vector-ref a 5) (vector-ref b 5)))]
         [_ (vector-set! c 6 (+ (vector-ref a 6) (vector-ref b 6)))]
         [_ (vector-set! c 7 (- (vector-ref a 7) (vector-ref b 7)))]
         [acc 0]
         [guard 0]
         [limit (read)]
         [tmp (make-vector 1)])
    (begin
      ;; copy some entries around with a temp box
      (vector-set! tmp 0 (vector-ref c 0))
      (vector-set! c 0 (vector-ref c 7))
      (vector-set! c 7 (vector-ref tmp 0))
      (vector-set! tmp 0 (vector-ref c 2))
      (vector-set! c 2 (vector-ref c 5))
      (vector-set! c 5 (vector-ref tmp 0))
      ;; accumulate acc from scattered constant positions
      (set! acc (+ acc (vector-ref c 0)))
      (set! acc (+ acc (vector-ref c 1)))
      (set! acc (+ acc (vector-ref c 3)))
      (set! acc (+ acc (vector-ref c 4)))
      (set! acc (+ acc (vector-ref c 5)))
      (set! acc (+ acc (vector-ref c 6)))
      (set! acc (+ acc (vector-ref c 7)))
      ;; big scalar while to push pipeline stress
      (while (and (< guard limit) (not (eq? guard 1000000)))
             (begin (set! acc (+ acc 2))
		    (set! guard (+ guard 1))))
      ;; final conditional tweak
      (if (< (vector-ref a 0) (vector-ref b 0))
          (+ acc 42)
          (- acc 42)))))
