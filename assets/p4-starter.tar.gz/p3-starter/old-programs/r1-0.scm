(program (let ([a 1]) a))
