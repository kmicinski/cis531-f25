(program 42)
