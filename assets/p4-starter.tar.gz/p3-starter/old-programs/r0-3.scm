(program (+ (read) (- (read))))
