(program
  (let ([n (read)])
    (let ([a 0])
      (let ([b 1])
        (let ([sum (+ a b)])
          (+ n (+ sum (- n))))))))
