(program (+ (read) (+ (read) (+ (read) (read)))))
