(program (+ (+ 5 3) (- (+ 2 (read)))))
