(program (- 5))
