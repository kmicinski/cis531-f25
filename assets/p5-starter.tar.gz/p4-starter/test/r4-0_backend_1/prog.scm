(program (read))
