(program (let ([x 2]) (let ([x x]) (let ([x x]) x))))
